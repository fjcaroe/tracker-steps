from . import hr_libro_remuneraciones_wizard
