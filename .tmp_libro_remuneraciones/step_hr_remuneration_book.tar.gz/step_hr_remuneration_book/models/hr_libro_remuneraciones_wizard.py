import base64
import csv
import io
import re
from urllib.parse import urlencode

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError


class HrLibroRemuneracionesWizard(models.TransientModel):
    _name = "step.hr.remuneration.book.wizard"
    _description = "Libro de Remuneraciones Steps"

    company_id = fields.Many2one(
        "res.company", required=True, default=lambda self: self.env.company, string="Empresa"
    )
    date_from = fields.Date(
        required=True,
        string="Fecha desde",
        default=lambda self: fields.Date.context_today(self).replace(day=1),
    )
    date_to = fields.Date(
        required=True, string="Fecha hasta", default=fields.Date.context_today
    )

    @api.onchange("date_from")
    def _onchange_date_from(self):
        if self.date_from:
            self.date_to = fields.Date.end_of(self.date_from, "month")

    def _step_validate_period(self):
        self.ensure_one()
        if self.date_from > self.date_to:
            raise ValidationError(_("La fecha desde no puede ser mayor que la fecha hasta."))
        if self.company_id not in self.env.companies:
            raise UserError(_("No tiene acceso a la empresa seleccionada."))

    def _step_get_payslips(self):
        self.ensure_one()
        self._step_validate_period()
        payslips = self.env["hr.payslip"].search(
            [
                ("date_from", ">=", self.date_from),
                ("date_to", "<=", self.date_to),
                ("company_id", "=", self.company_id.id),
                ("state", "in", ["done", "paid"]),
            ],
            order="employee_id, date_from, id",
        )
        if not payslips:
            raise UserError(
                _(
                    "No se encontraron liquidaciones en estado Hecho o Pagado "
                    "para el período y empresa seleccionados."
                )
            )
        return payslips

    @staticmethod
    def _step_parse_csv_content(csv_content):
        rows = list(csv.reader(io.StringIO(csv_content), delimiter=";"))
        if not rows:
            return [], []
        width = len(rows[0])
        normalized = [row[:width] + [""] * max(0, width - len(row)) for row in rows[1:]]
        return rows[0], normalized

    @staticmethod
    def _step_chunks(values, size=2):
        return [values[index : index + size] for index in range(0, len(values), size)]

    @staticmethod
    def _step_normalize_rut(value):
        return re.sub(r"[^0-9kK]", "", value or "").upper().lstrip("0")

    def _step_csv_from_simpledigital(self, payslips):
        from odoo.addons.l10n_cl_simpledigital_payroll.controllers.libro_remuneraciones import (
            LibroRemuneracionesController,
        )

        return LibroRemuneracionesController()._generate_csv_content(
            payslips, include_header=True
        )

    def _step_csv_from_electronic_book(self):
        source_wizard = (
            self.env["hr.salary.employee.month"]
            .with_company(self.company_id)
            .with_context(allowed_company_ids=[self.company_id.id])
            .create({"end_date": self.date_to})
        )
        action = source_wizard.library()
        match = re.search(r"[?&]id=(\d+)", action.get("url", ""))
        if not match:
            raise UserError(_("La fuente de nómina no devolvió un archivo válido."))
        attachment = self.env["ir.attachment"].sudo().browse(int(match.group(1))).exists()
        if not attachment or not attachment.datas:
            raise UserError(_("No fue posible leer el Libro de Remuneraciones generado."))
        try:
            return base64.b64decode(attachment.datas).decode("cp1252")
        finally:
            attachment.unlink()

    def _step_build_book_data(self):
        """Reuse the installed Chilean payroll provider as calculation source."""
        self.ensure_one()
        payslips = self._step_get_payslips()
        installed_modules = set(
            self.env["ir.module.module"]
            .sudo()
            .search(
                [
                    ("name", "in", ["l10n_cl_simpledigital_payroll", "l10n_cl_hr_electronic_book"]),
                    ("state", "=", "installed"),
                ]
            )
            .mapped("name")
        )
        if "l10n_cl_simpledigital_payroll" in installed_modules:
            csv_content = self._step_csv_from_simpledigital(payslips)
            source = "SimpleDigital"
        elif "l10n_cl_hr_electronic_book" in installed_modules:
            csv_content = self._step_csv_from_electronic_book()
            source = "Libro de Remuneraciones Electrónico"
        else:
            raise UserError(
                _(
                    "Debe instalar una fuente de nómina chilena compatible: "
                    "SimpleDigital o Libro de Remuneraciones Electrónico."
                )
            )
        headers, rows = self._step_parse_csv_content(csv_content)
        if not headers or not rows:
            raise UserError(_("La fuente de nómina no generó información para el período."))

        sections = [
            (_("Identificación, contrato y jornada"), 0, 46),
            (_("Haberes"), 46, 89),
            (_("Descuentos y aportes"), 89, 127),
            (_("Totales"), 127, len(headers)),
        ]
        payslips_by_rut = {
            self._step_normalize_rut(payslip.employee_id.identification_id): payslip
            for payslip in payslips
            if payslip.employee_id.identification_id
        }
        employees = []
        for row_index, row in enumerate(rows):
            payslip = payslips_by_rut.get(self._step_normalize_rut(row[0]))
            if not payslip and row_index < len(payslips):
                payslip = payslips[row_index]
            employee_sections = []
            for title, start, end in sections:
                items = [
                    {"label": label, "value": row[index] if index < len(row) else ""}
                    for index, label in enumerate(headers[start:end], start=start)
                ]
                employee_sections.append(
                    {"title": title, "rows": self._step_chunks(items, 2)}
                )
            employees.append(
                {
                    "name": payslip.employee_id.name if payslip else _("Trabajador"),
                    "identification": (payslip.employee_id.identification_id if payslip else False)
                    or row[0],
                    "payslip": payslip,
                    "sections": employee_sections,
                }
            )
        return {
            "headers": headers,
            "rows": rows,
            "payslips": payslips,
            "employees": employees,
            "source": source,
        }

    def _step_download_url(self, route):
        self.ensure_one()
        self._step_validate_period()
        query = urlencode(
            {
                "date_from": self.date_from.isoformat(),
                "date_to": self.date_to.isoformat(),
                "company_id": self.company_id.id,
            }
        )
        return {"type": "ir.actions.act_url", "url": f"{route}?{query}", "target": "self"}

    def action_generate_xlsx(self):
        self._step_get_payslips()
        return self._step_download_url("/step/payroll/remuneration-book/xlsx")

    def action_generate_pdf(self):
        self.ensure_one()
        self._step_get_payslips()
        return self.env.ref(
            "step_hr_remuneration_book.action_report_remuneration_book"
        ).report_action(self)
