from odoo import api, models


class RemunerationBookReport(models.AbstractModel):
    _name = "report.step_hr_remuneration_book.book_pdf"
    _description = "Libro de Remuneraciones Steps"

    @api.model
    def _get_report_values(self, docids, data=None):
        wizards = self.env["step.hr.remuneration.book.wizard"].browse(docids)
        wizard = wizards[:1]
        book = wizard._step_build_book_data()
        return {
            "doc_ids": docids,
            "doc_model": "step.hr.remuneration.book.wizard",
            "docs": wizard,
            "book": book,
            "company": wizard.company_id,
        }
