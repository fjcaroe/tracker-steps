import io
import re
from datetime import datetime

import xlsxwriter

from odoo import http
from odoo.http import content_disposition, request


class StepsRemunerationBookController(http.Controller):
    @http.route(
        "/step/payroll/remuneration-book/xlsx",
        type="http",
        auth="user",
        methods=["GET"],
    )
    def download_xlsx(self, date_from, date_to, company_id, **kwargs):
        company = request.env["res.company"].browse(int(company_id)).exists()
        if not company or company not in request.env.companies:
            return request.not_found()

        wizard = request.env["step.hr.remuneration.book.wizard"].create(
            {
                "company_id": company.id,
                "date_from": datetime.strptime(date_from, "%Y-%m-%d").date(),
                "date_to": datetime.strptime(date_to, "%Y-%m-%d").date(),
            }
        )
        book = wizard._step_build_book_data()
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {"in_memory": True})
        sheet = workbook.add_worksheet("Libro DT")
        title_format = workbook.add_format(
            {
                "bold": True,
                "font_size": 16,
                "font_color": "#FFFFFF",
                "bg_color": "#174A35",
                "align": "left",
                "valign": "vcenter",
            }
        )
        info_format = workbook.add_format(
            {"font_color": "#365B4A", "bg_color": "#EAF4EE", "valign": "vcenter"}
        )
        header_format = workbook.add_format(
            {
                "bold": True,
                "font_color": "#FFFFFF",
                "bg_color": "#2E6B4C",
                "border": 1,
                "border_color": "#D4E3DA",
                "text_wrap": True,
                "align": "center",
                "valign": "vcenter",
            }
        )
        text_format = workbook.add_format({"border": 1, "border_color": "#DCE7E0"})
        alt_format = workbook.add_format(
            {"border": 1, "border_color": "#DCE7E0", "bg_color": "#F5F9F6"}
        )

        last_column = max(0, len(book["headers"]) - 1)
        sheet.merge_range(0, 0, 0, last_column, "Libro de Remuneraciones", title_format)
        sheet.merge_range(
            1,
            0,
            1,
            last_column,
            f"{company.name} · Período {date_from} a {date_to} · {len(book['rows'])} registros · Fuente: {book['source']}",
            info_format,
        )
        sheet.set_row(0, 28)
        sheet.set_row(1, 22)
        sheet.set_row(2, 54)
        for column, header in enumerate(book["headers"]):
            sheet.write(2, column, header, header_format)
            sheet.set_column(column, column, min(28, max(12, len(header) // 2)))
        for row_number, row in enumerate(book["rows"], start=3):
            row_format = alt_format if row_number % 2 else text_format
            for column, value in enumerate(row):
                sheet.write(row_number, column, value, row_format)
        sheet.freeze_panes(3, 1)
        sheet.autofilter(2, 0, 2 + len(book["rows"]), last_column)
        sheet.set_landscape()
        sheet.fit_to_pages(1, 0)
        sheet.repeat_rows(0, 2)
        workbook.close()
        output.seek(0)

        safe_company = re.sub(r"[^A-Za-z0-9_-]+", "_", company.name).strip("_")
        filename = f"libro_remuneraciones_{safe_company}_{date_from[:7]}.xlsx"
        return request.make_response(
            output.getvalue(),
            headers=[
                ("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
                ("Content-Disposition", content_disposition(filename)),
                ("Cache-Control", "no-store"),
            ],
        )
