from odoo.tests.common import TransactionCase


class TestRemunerationBookHelpers(TransactionCase):
    def test_parse_csv_normalizes_short_rows(self):
        wizard_model = self.env["step.hr.remuneration.book.wizard"]
        headers, rows = wizard_model._step_parse_csv_content("A;B;C\r\n1;2\r\n")
        self.assertEqual(headers, ["A", "B", "C"])
        self.assertEqual(rows, [["1", "2", ""]])

    def test_chunks_keep_last_item(self):
        wizard_model = self.env["step.hr.remuneration.book.wizard"]
        self.assertEqual(wizard_model._step_chunks([1, 2, 3], 2), [[1, 2], [3]])
