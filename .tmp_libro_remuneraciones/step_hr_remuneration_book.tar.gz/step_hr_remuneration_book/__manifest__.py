{
    "name": "Steps - Libro de Remuneraciones",
    "version": "18.0.1.0.0",
    "category": "Human Resources/Payroll",
    "summary": "Libro de Remuneraciones chileno en CSV, Excel y PDF",
    "author": "Steps Consulting",
    "website": "https://stepsapp.cl",
    "license": "LGPL-3",
    "depends": ["hr_payroll"],
    "data": [
        "security/ir.model.access.csv",
        "report/remuneration_book_report.xml",
        "views/hr_libro_remuneraciones_wizard_views.xml",
    ],
    "installable": True,
    "application": True,
}
